#!/usr/bin/python
# -*- coding: latin1 -*-
"""
SYNOPSIS

    

DESCRIPTION

    

EXAMPLES

    

EXIT STATUS

    

AUTHOR

    luca.mella@studio.unibo.it

LICENSE

    Attribution-NonCommercial-ShareAlike 3.0 Unported (CC BY-NC-SA 3.0)

VERSION

    0.2
"""

import numpy as np
import Image, sys, re
from optparse import OptionParser

parser = OptionParser("usage: %prog [OPTIONS] ARGS \nDefault output in <imagepath>-lsb.png")

parser.add_option("-f", "--file", dest="filename", action="store", type="string",
                  help="image to analyze", metavar="FILE")
parser.add_option("-c", "--channel",dest="channel", action="store", type="string",
                  default='rgb',help="channel to consider [r][g][b][a]", metavar="CHANNEL")
parser.add_option("-b", "--bitnum",dest="bitnum", action="store", type="int",
                  default=0,help="bit to consider in pixel\'s channels [0..7]", metavar="BITNUM")


(options, args) = parser.parse_args()

if options.filename == None :
    parser.error("Input image is mandatory!")

mtch = re.compile('[a|r|g|b]{1,4}').match(options.channel.lower())

if mtch is None :
    print 'ERROR: invalid channel specification'
    exit(-1)

inputim = options.filename
channels = mtch.group()
bitnum = options.bitnum%7
outim = inputim+"-lsb-"+channels+".png"

normal_table = [0.0,0.5000, 0.0627, 0.4750,  0.1257,   0.4500,  0.1891,   0.4250,  0.2533,   0.4000,  0.3186,   0.3750,  0.3853,   0.3500,  0.4538,   0.3250,  0.5244,   0.3000,  0.5978,   0.2750,  0.6745,   0.2500,  0.7554,   0.2250,  0.8416,   0.2000,  0.9346,   0.1750,  1.0364,   0.1500,  1.1503,   0.1250,  1.2816,   0.1000,  1.4395,   0.0750,  1.6449,   0.0500,  1.9600,   0.0250,  2.3263,   0.0100,  2.5758,   0.0050,  3.0902,   0.0010,  3.2905,   0.0005,  3.7190,   0.0001]
n = Image.open(inputim)
n = n.convert('RGBA')
m = n.load()
s = n.size

print 'Image size: '+str(s)
print 'Processing..'

for x in range(s[0]):
    for y in range(s[1]):
        #print m[x,y]
        r,g,b,a = m[(x,y)]
        r1 = 0
        g1 = 0
        b1 = 0
        a1 = 255
        if ( 'r' in channels and (r & (0x01  <<bitnum)  )>>bitnum  == 1 ):
             r1= 255
        else:
             r1=0
        if ( 'g' in channels and (g & (0x01  <<bitnum)  )>>bitnum   == 1):
             g1=255
        else:
             g1=0
        if ( 'b' in channels and (b & (0x01  <<bitnum)  )>>bitnum   == 1):
             b1=255
        else:
             b1=0
        if ( 'a' in channels and (a & (0x01  <<bitnum)  )>>bitnum   == 1):
             a1=255
        else:
             if ( 'a' in channels):
                  a1=0
        m[(x,y)] = r1,g1,b1,a1

print 'Writing output to file: %s' %(outim)
n.save(outim, "PNG")

